<?php
/*
Version: 170220
Text Domain: comet-cache
Plugin Name: Comet Cache Pro
Network: true

Author: WebSharks, Inc.
Author URI: http://websharks-inc.com/

Plugin URI: http://cometcache.com/
Description: Comet Cache is an advanced WordPress caching plugin inspired by simplicity.
*/
if (!defined('WPINC')) {
    exit('Do NOT access this file directly.');
}
require_once dirname(__FILE__).'/plugin.php';
